shell variables and expansions
