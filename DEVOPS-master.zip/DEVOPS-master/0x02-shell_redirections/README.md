Shell I/O redirections
